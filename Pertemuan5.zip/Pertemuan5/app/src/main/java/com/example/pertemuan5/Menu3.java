package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Menu3 extends AppCompatActivity {
    EditText eTxtNama;
    Button bSubmit;
    TextView txtHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu3);

        eTxtNama = findViewById(R.id.EditText1);
        bSubmit = findViewById(R.id.Btn1);
        txtHasil = findViewById(R.id.txtHasil);
    }

    public void getHasil(View v){
        String res = eTxtNama.getText().toString();
        txtHasil.setText("Nama Anda adalah : "+res);
    }
}
