package com.example.pertemuan5;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.Button;

public class Menu1 extends AppCompatActivity {

    Button btnMerah;
    Button btnHijau;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);


        btnMerah = findViewById(R.id.Btn1);
        btnHijau = findViewById(R.id.Btn2);
    }

    public void Rubah_Warna(View v){
        btnMerah.setBackgroundColor(Color.RED);
    }

    public void Rubah_Warna_Hijau(View v){
        btnMerah.setBackgroundColor(Color.GREEN);
    }
}
